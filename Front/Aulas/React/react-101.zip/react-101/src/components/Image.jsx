export default function Image(){
    return(
        <figure>
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQhiEL_jfuTB5m1p3NYND_HdeNxj6CMZ9YkQ&s"></img>
        </figure>
    )
}